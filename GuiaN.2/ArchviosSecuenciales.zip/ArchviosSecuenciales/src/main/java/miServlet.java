/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 *
 * @author Practica
 */
public class miServlet extends HttpServlet {

    public void PersistenciaArchivo(String nombre, String apellido, String tipoDocumento, String numeroDocumento, 
            String correo, String fechaNacimiento, String rol, String contraseña) {
        System.out.println("FuncionaPersistenciaArchivo");
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Frnklin\\Documents\\NetBeansProjects\\archivoSecuencial.txt"));   
             BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\Users\\Frnklin\\Documents\\NetBeansProjects\\archivoSecuencial.txt", true));){  
            //Escribimos en el fichero
            bw.write("Numero documento: "+numeroDocumento+ "\n" 
                    +"Tipo Documento: "+tipoDocumento+"\n"
                    +"Nombre: "+nombre+"\n"
                    +"Apellido: "+apellido+"\n"
                    +"Correo electronico: "+correo+"\n"
                    +"Fecha nacimiento: "+fechaNacimiento+"\n"
                    +"Rol: "+rol+"\n"  
                    +"Contraseña: "+contraseña+"\n");
            bw.newLine();
            //Guardamos los cambios del fichero
            bw.flush();
            //Leemos el fichero y lo mostramos por pantalla
            String linea = br.readLine();
            while (linea != null) {
                System.out.println(linea);
                linea = br.readLine();
            }
        } catch (IOException e) {
            System.out.println("Error E/S: " + e);
        }

    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PersistenciaArchivo(request.getParameter("nombre"), request.getParameter("apeliido"), request.getParameter("tipoDocumento"), 
                request.getParameter("numeroDocumento"), request.getParameter("correo"), request.getParameter("fechaNacimiento"),
                request.getParameter("rol"),request.getParameter("contraseña")  );
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet miServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>¡Usuario Registrado!</h1>");
            out.println("<h2>nombre: " + request.getParameter("nombre") + "</h2>");
            out.println("<h2>apellido : " + request.getParameter("apeliido") + "</h2>");
            out.println("<h2>Tipo documento: " + request.getParameter("tipoDocumento") + "</h2>");
            out.println("<h2>Nunmero documento: " + request.getParameter("numeroDocumento") + "</h2>");
            out.println("<h2>correo: " + request.getParameter("correo") + "</h2>");
            out.println("<h2>rol: " + request.getParameter("rol") + "</h2>");
            out.println("<h2>contraseña: " + request.getParameter("contraseña") + "</h2>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}